import csv
import os
import re
import mysql.connector

# Database connection configuration
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "@Gusau00",
    "database": "mock7"
}

def sanitize_filename(name):
    """Removes characters that are illegal in file and folder names."""
    return re.sub(r'[\\/*?:"<>|]', "", name).replace(" ", "_")

def export_exams_to_nested_folders():
    try:
        # Connect to the database
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        
        # 1. Fetch all departments
        cursor.execute("SELECT id, code FROM dept")
        departments = cursor.fetchall()
        
        if not departments:
            print("No departments found in the database.")
            return

        for dept in departments:
            dept_id = dept['id']
            dept_code = sanitize_filename(dept['code']) # Clean department folder name
            
            # 2. Fetch all exams for this specific department
            exam_query = """
                SELECT id, code, title, level 
                FROM exams 
                WHERE dept = %s
            """
            cursor.execute(exam_query, (dept_id,))
            exams = cursor.fetchall()
            
            for exam in exams:
                exam_id = exam['id']
                exam_code = exam['code']
                exam_title = exam['title']
                exam_level = sanitize_filename(exam['level']) # Clean level folder name
                
                # Dynamically build the path: dept_folder/level_folder
                target_folder = os.path.join(dept_code, exam_level)
                
                # Create the nested folders if they do not exist
                if not os.path.exists(target_folder):
                    os.makedirs(target_folder)
                    print(f"Created directory structure: {target_folder}/")
                
                # 3. Fetch all questions for this specific exam
                question_query = """
                    SELECT question, option1, option2, option3, option4, answer 
                    FROM question 
                    WHERE exam = %s
                """
                cursor.execute(question_query, (exam_id,))
                questions = cursor.fetchall()
                
                # Construct the dynamic CSV filename
                raw_filename = f"{dept['code']}_{exam['level']}_{exam_code}_{exam_title}.csv"
                filename = sanitize_filename(raw_filename)
                
                # Combine the nested directory path with the filename
                file_path = os.path.join(target_folder, filename)
                
                # 4. Write data to CSV format
                with open(file_path, mode='w', newline='', encoding='utf-8') as csv_file:
                    writer = csv.writer(csv_file)
                    
                    # Write headers
                    writer.writerow(['Question', 'Option1', 'Option2', 'Option3', 'Option4', 'Answer'])
                    
                    # Write rows
                    for q in questions:
                        writer.writerow([
                            q['question'],
                            q['option1'],
                            q['option2'],
                            q['option3'],
                            q['option4'],
                            q['answer']
                        ])
                
                print(f" -> Exported CSV: {file_path} ({len(questions)} questions)")
                
    except mysql.connector.Error as err:
        print(f"Database Error: {err}")
    finally:
        if 'conn' in locals() and conn.is_connected():
            cursor.close()
            conn.close()

if __name__ == "__main__":
    export_exams_to_nested_folders()
